import sys
import os
sys.path.append(os.path.dirname(__file__))


class RSSParser:
    @classmethod
    def text_cleaner(cls, param):
        pass

    @classmethod
    def time_parser(cls, param):
        pass

    @classmethod
    def check_url(cls, param):
        pass

    @classmethod
    def parser(cls, self, param):
        pass

    @classmethod
    def rss_print(cls, list_of_items):
        pass

    @classmethod
    def json_print(cls, list_of_items):
        pass

    @classmethod
    def save_to_html(cls, self, param):
        pass


class RSSarchive:
    @classmethod
    def getarchive(cls, param):
        pass